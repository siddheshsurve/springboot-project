package com.example.dbconn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbconnApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbconnApplication.class, args);
	}

}
