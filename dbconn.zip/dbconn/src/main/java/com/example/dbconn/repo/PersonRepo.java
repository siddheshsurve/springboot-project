package com.example.dbconn.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.dbconn.entity.Person;

public interface PersonRepo extends JpaRepository<Person, Integer> {
//	@Query("Select case when count(s) > 0 then true else false"
//			+ "end from person s where s.personId = ?1")
//	boolean existsById(Integer id);
	@Query("SELECT CASE WHEN COUNT(s) > 0 THEN true ELSE false END FROM Person s WHERE s.personId = ?1")
	boolean isPersonExistById(Integer personId);


}
