package com.example.dbconn.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.ListCrudRepository;
import org.springframework.stereotype.Service;

import com.example.dbconn.entity.Person;
import com.example.dbconn.repo.PersonRepo;

@Service
public class PersonService {
	
	@Autowired
	private PersonRepo repo;
	
	public List<Person> getAllPerson() {
		return ((ListCrudRepository<Person, Integer>) this.repo).findAll();
	}
	
	//create at service testing
	public PersonService(PersonRepo repo) {
		this.repo = repo;
	}

}
