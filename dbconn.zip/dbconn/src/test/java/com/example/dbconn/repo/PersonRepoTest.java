package com.example.dbconn.repo;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


import com.example.dbconn.entity.Person;

@SpringBootTest
public class PersonRepoTest {
	@Autowired
	private PersonRepo personRepo;
	@Test
	void isPersonExistById() {
		Person person = new Person(14, "sarvesh", "raigad");
		personRepo.save(person);
		
		boolean acRes = personRepo.isPersonExistById(14);
		assertThat(acRes).isTrue();
		
	}
	
	@BeforeEach
	void setUp() {
		System.out.println("setup started...");
	}
	
	@AfterEach
	void tearDown() {
		System.out.println("test over");
	}
}
