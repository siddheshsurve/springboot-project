package com.example.dbconn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbconnApplicationTests {

	@Test
	void contextLoads() {
	}

}
